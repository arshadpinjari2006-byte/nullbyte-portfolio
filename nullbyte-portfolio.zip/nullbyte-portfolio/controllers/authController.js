const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

// In production, use a real database. Here we use a hardcoded admin.
const ADMIN_USER = {
  username: 'admin',
  // Password: nullbyte2024 (pre-hashed)
  passwordHash: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'
};

const login = async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required.' });
    }

    if (username !== ADMIN_USER.username) {
      return res.status(401).json({ error: 'Invalid credentials.' });
    }

    const isMatch = await bcrypt.compare(password, ADMIN_USER.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid credentials.' });
    }

    req.session.isAuthenticated = true;
    req.session.user = { username: ADMIN_USER.username };

    return res.json({ success: true, message: 'Login successful.' });
  } catch (err) {
    return res.status(500).json({ error: 'Server error during login.' });
  }
};

const logout = (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.status(500).json({ error: 'Logout failed.' });
    res.json({ success: true, message: 'Logged out.' });
  });
};

const status = (req, res) => {
  if (req.session.isAuthenticated) {
    return res.json({ authenticated: true, user: req.session.user });
  }
  return res.json({ authenticated: false });
};

module.exports = { login, logout, status };

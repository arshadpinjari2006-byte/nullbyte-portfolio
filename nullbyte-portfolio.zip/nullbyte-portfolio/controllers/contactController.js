const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const DB_PATH = path.join(__dirname, '../data/contacts.json');

const readContacts = () => {
  try {
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify([], null, 2));
      return [];
    }
    const raw = fs.readFileSync(DB_PATH, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return [];
  }
};

const writeContacts = (data) => {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
};

const submitContact = (req, res) => {
  const { name, email, subject, message } = req.body;

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Name, email, and message are required.' });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: 'Invalid email format.' });
  }

  if (message.length > 2000) {
    return res.status(400).json({ error: 'Message is too long (max 2000 chars).' });
  }

  const contacts = readContacts();
  const newContact = {
    id: uuidv4(),
    name: name.trim().slice(0, 100),
    email: email.trim().toLowerCase(),
    subject: (subject || 'No Subject').trim().slice(0, 200),
    message: message.trim().slice(0, 2000),
    ip: req.ip,
    timestamp: new Date().toISOString(),
    read: false
  };

  contacts.push(newContact);
  writeContacts(contacts);

  return res.json({ success: true, message: 'Message received. I\'ll get back to you soon!' });
};

const getContacts = (req, res) => {
  const contacts = readContacts();
  return res.json({ contacts });
};

const markRead = (req, res) => {
  const { id } = req.params;
  const contacts = readContacts();
  const idx = contacts.findIndex(c => c.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Contact not found.' });
  contacts[idx].read = true;
  writeContacts(contacts);
  return res.json({ success: true });
};

const deleteContact = (req, res) => {
  const { id } = req.params;
  let contacts = readContacts();
  const before = contacts.length;
  contacts = contacts.filter(c => c.id !== id);
  if (contacts.length === before) return res.status(404).json({ error: 'Contact not found.' });
  writeContacts(contacts);
  return res.json({ success: true });
};

module.exports = { submitContact, getContacts, markRead, deleteContact };

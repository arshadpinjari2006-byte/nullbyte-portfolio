const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const DB_PATH = path.join(__dirname, '../data/posts.json');

const readPosts = () => {
  try {
    if (!fs.existsSync(DB_PATH)) {
      const seed = getSeedPosts();
      fs.writeFileSync(DB_PATH, JSON.stringify(seed, null, 2));
      return seed;
    }
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
  } catch {
    return [];
  }
};

const writePosts = (data) => {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
};

const getSeedPosts = () => [
  {
    id: uuidv4(),
    title: 'Breaking into Bug Bounty: A Hacker\'s Roadmap',
    slug: 'breaking-into-bug-bounty',
    excerpt: 'A practical guide to starting your bug bounty journey — from recon methodologies to writing impactful reports.',
    content: `Bug bounty hunting is one of the most rewarding ways to apply offensive security skills ethically. In this post, I break down the exact methodology I use when approaching a new target.\n\n## Reconnaissance Phase\nPassive recon is where I start every engagement. Tools like Amass, Subfinder, and HTTPX help map the attack surface before you touch a single endpoint.\n\n## Finding the Low-Hanging Fruit\nMost critical bugs aren't zero-days — they're logic flaws, IDOR vulnerabilities, and misconfigured cloud storage. Train your eye to spot what developers overlook.\n\n## Writing a Winning Report\nA well-written report doubles your payout chances. Include: clear reproduction steps, impact statement, CVSS score, and a suggested fix.`,
    tags: ['Bug Bounty', 'Recon', 'Methodology'],
    category: 'Offensive Security',
    author: 'NullByte',
    published: true,
    views: 1247,
    createdAt: '2024-11-15T10:30:00Z',
    updatedAt: '2024-11-15T10:30:00Z'
  },
  {
    id: uuidv4(),
    title: 'Dissecting CVE-2024-XXXX: A Deep Dive into Memory Corruption',
    slug: 'dissecting-memory-corruption',
    excerpt: 'A technical walkthrough of a real-world memory corruption vulnerability — how it works, how it was exploited, and how to patch it.',
    content: `Memory corruption vulnerabilities remain some of the most impactful bugs in modern software. This post walks through a heap overflow I discovered in a popular open-source library.\n\n## Root Cause Analysis\nThe bug was triggered by a malformed packet with a length field larger than the allocated buffer. Classic off-by-one, but the consequences were devastating.\n\n## Exploitation Path\nBy grooming the heap, we could reliably place our controlled data adjacent to a function pointer, leading to arbitrary code execution.\n\n## Patch Analysis\nThe vendor fixed this by adding a bounds check before the memcpy. Simple, effective, but shows the importance of input validation at every layer.`,
    tags: ['CVE', 'Memory Corruption', 'Exploit Development'],
    category: 'Vulnerability Research',
    author: 'NullByte',
    published: true,
    views: 892,
    createdAt: '2024-10-28T14:00:00Z',
    updatedAt: '2024-10-28T14:00:00Z'
  },
  {
    id: uuidv4(),
    title: 'Red Team Tactics: Living Off the Land',
    slug: 'red-team-living-off-the-land',
    excerpt: 'How modern red teams evade EDR solutions using only built-in OS tools — no custom malware required.',
    content: `The best red team operations leave minimal trace. By leveraging LOLBAS (Living Off the Land Binaries and Scripts), we can move through an environment using tools the defender already trusts.\n\n## Initial Access via Phishing\nSpear-phishing with a weaponized Office document using only macros and certutil. No dropped executables.\n\n## Lateral Movement\nWMIC, PsExec, and PowerShell Remoting — all built-in, all often overlooked in detection rules.\n\n## Defense Evasion\nEvent log manipulation, timestomping, and AMSI bypass techniques that work in 2024.`,
    tags: ['Red Team', 'LOLBAS', 'Evasion'],
    category: 'Red Teaming',
    author: 'NullByte',
    published: true,
    views: 2103,
    createdAt: '2024-09-10T09:00:00Z',
    updatedAt: '2024-09-10T09:00:00Z'
  }
];

const getAllPosts = (req, res) => {
  const posts = readPosts();
  const publicPosts = posts
    .filter(p => p.published)
    .map(({ content, ...rest }) => rest)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return res.json({ posts: publicPosts });
};

const getPost = (req, res) => {
  const posts = readPosts();
  const post = posts.find(p => p.slug === req.params.slug && p.published);
  if (!post) return res.status(404).json({ error: 'Post not found.' });

  // Increment views
  const all = readPosts();
  const idx = all.findIndex(p => p.id === post.id);
  if (idx !== -1) { all[idx].views++; writePosts(all); }

  return res.json({ post });
};

const createPost = (req, res) => {
  const { title, excerpt, content, tags, category } = req.body;
  if (!title || !content) return res.status(400).json({ error: 'Title and content required.' });

  const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  const posts = readPosts();

  const newPost = {
    id: uuidv4(),
    title, slug, excerpt: excerpt || '',
    content,
    tags: tags || [],
    category: category || 'General',
    author: 'NullByte',
    published: true,
    views: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  posts.push(newPost);
  writePosts(posts);
  return res.status(201).json({ success: true, post: newPost });
};

const updatePost = (req, res) => {
  const posts = readPosts();
  const idx = posts.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Post not found.' });

  posts[idx] = { ...posts[idx], ...req.body, updatedAt: new Date().toISOString() };
  writePosts(posts);
  return res.json({ success: true, post: posts[idx] });
};

const deletePost = (req, res) => {
  let posts = readPosts();
  const before = posts.length;
  posts = posts.filter(p => p.id !== req.params.id);
  if (posts.length === before) return res.status(404).json({ error: 'Post not found.' });
  writePosts(posts);
  return res.json({ success: true });
};

module.exports = { getAllPosts, getPost, createPost, updatePost, deletePost };

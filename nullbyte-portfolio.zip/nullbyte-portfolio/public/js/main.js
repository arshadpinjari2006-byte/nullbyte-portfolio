/* ===== NULLBYTE PORTFOLIO - MAIN JS ===== */

// ---- MATRIX RAIN ----
(function() {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  document.getElementById('matrix-bg').appendChild(canvas);

  const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
  resize();
  window.addEventListener('resize', resize);

  const chars = 'アイウエオカキクケコ01アBCDEFGHIJKLMN</>{}[]$#@!%^&*()_-+=/\\|';
  const fontSize = 12;
  let cols = [];

  const init = () => {
    cols = [];
    for (let i = 0; i < Math.floor(canvas.width / fontSize); i++) {
      cols.push(Math.floor(Math.random() * canvas.height / fontSize));
    }
  };
  init();
  window.addEventListener('resize', init);

  setInterval(() => {
    ctx.fillStyle = 'rgba(3,12,15,0.05)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#00ff9d';
    ctx.font = `${fontSize}px 'Share Tech Mono', monospace`;
    cols.forEach((y, i) => {
      const char = chars[Math.floor(Math.random() * chars.length)];
      ctx.fillText(char, i * fontSize, y * fontSize);
      if (y * fontSize > canvas.height && Math.random() > 0.975) cols[i] = 0;
      else cols[i]++;
    });
  }, 50);
})();

// ---- NAV SCROLL ----
window.addEventListener('scroll', () => {
  document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 20);
});

// ---- HAMBURGER ----
document.getElementById('hamburger').addEventListener('click', () => {
  document.querySelector('.nav-links').classList.toggle('open');
});

// ---- TYPED HERO ----
const typedLines = [
  { text: 'whoami', delay: 600 },
];
const heroOutput = [
  '<p class="highlight-line">  NullByte // Security Researcher &amp; Penetration Tester</p>',
  '<p>  Specializing in offensive security, web application testing,</p>',
  '<p>  vulnerability research, and red team operations.</p>',
  '<p class="highlight-line">  Status: <span style="color:var(--green)">[ AVAILABLE FOR ENGAGEMENTS ]</span></p>',
];

let lineIndex = 0;
let charIndex = 0;
const typedEl = document.getElementById('typed-text');

function typeNextChar() {
  if (lineIndex >= typedLines.length) {
    setTimeout(showOutput, 300);
    return;
  }
  const line = typedLines[lineIndex];
  if (charIndex < line.text.length) {
    typedEl.textContent += line.text[charIndex];
    charIndex++;
    setTimeout(typeNextChar, 80 + Math.random() * 40);
  } else {
    lineIndex++;
    charIndex = 0;
    setTimeout(typeNextChar, 400);
  }
}

function showOutput() {
  const out = document.getElementById('hero-output');
  heroOutput.forEach((html, i) => {
    setTimeout(() => {
      const div = document.createElement('div');
      div.innerHTML = html;
      out.appendChild(div);
    }, i * 120);
  });
}

setTimeout(typeNextChar, 1000);

// ---- COUNTER ANIMATION ----
const observerOptions = { threshold: 0.5 };
const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.querySelectorAll('.stat-num').forEach(el => {
        const target = parseInt(el.dataset.target);
        let current = 0;
        const step = Math.ceil(target / 50);
        const timer = setInterval(() => {
          current = Math.min(current + step, target);
          el.textContent = current + (el.dataset.suffix || '');
          if (current >= target) clearInterval(timer);
        }, 30);
      });
      counterObserver.unobserve(entry.target);
    }
  });
}, observerOptions);

const statsRow = document.querySelector('.stats-row');
if (statsRow) counterObserver.observe(statsRow);

// ---- SCROLL REVEAL ----
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.skill-card, .project-card, .blog-card').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(20px)';
  el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
  revealObserver.observe(el);
});

// ---- BLOG LOADING ----
async function loadBlog() {
  const grid = document.getElementById('blog-grid');
  try {
    const res = await fetch('/api/blog');
    const data = await res.json();
    const posts = data.posts || [];

    if (!posts.length) {
      grid.innerHTML = '<p style="font-family:var(--font-mono);color:var(--text2)">No posts yet.</p>';
      return;
    }

    grid.innerHTML = posts.map(post => `
      <div class="blog-card" onclick="openPost('${post.slug}')">
        <div class="blog-meta">
          <span class="blog-cat">${escHtml(post.category)}</span>
          <span class="blog-date">${formatDate(post.createdAt)}</span>
        </div>
        <h3>${escHtml(post.title)}</h3>
        <p>${escHtml(post.excerpt)}</p>
        <div class="blog-tags">
          ${(post.tags || []).map(t => `<span>#${escHtml(t)}</span>`).join('')}
        </div>
        <div class="blog-views">👁 ${post.views} reads</div>
      </div>
    `).join('');

    // Re-observe new cards
    document.querySelectorAll('.blog-card').forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(20px)';
      el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      revealObserver.observe(el);
    });
  } catch {
    grid.innerHTML = '<p style="font-family:var(--font-mono);color:var(--red)">$ Error: Failed to fetch posts</p>';
  }
}

async function openPost(slug) {
  const modal = document.getElementById('post-modal');
  const content = document.getElementById('modal-content');
  content.innerHTML = '<p style="font-family:var(--font-mono);color:var(--text2)">Loading<span class="loading-dots"></span></p>';
  modal.style.display = 'flex';
  document.body.style.overflow = 'hidden';

  try {
    const res = await fetch(`/api/blog/${slug}`);
    const data = await res.json();
    const post = data.post;

    content.innerHTML = `
      <div style="margin-bottom:1rem">
        <span style="font-family:var(--font-mono);font-size:0.75rem;background:var(--green2);color:var(--bg);padding:2px 8px;border-radius:2px">${escHtml(post.category)}</span>
        <span style="font-family:var(--font-mono);font-size:0.75rem;color:var(--text2);margin-left:0.8rem">${formatDate(post.createdAt)}</span>
      </div>
      <h1>${escHtml(post.title)}</h1>
      <div style="margin:1.5rem 0;padding:1rem;background:rgba(0,255,157,0.04);border-left:3px solid var(--green);border-radius:2px">
        <p style="color:var(--cyan);font-style:italic">${escHtml(post.excerpt)}</p>
      </div>
      <div style="color:var(--text2);">${markdownToHtml(post.content)}</div>
      <div style="margin-top:2rem;display:flex;flex-wrap:wrap;gap:0.4rem">
        ${(post.tags || []).map(t => `<span style="font-family:var(--font-mono);font-size:0.7rem;color:var(--green2);border:1px solid rgba(0,255,157,0.2);padding:2px 8px;border-radius:2px">#${escHtml(t)}</span>`).join('')}
      </div>
    `;
  } catch {
    content.innerHTML = '<p style="color:var(--red);font-family:var(--font-mono)">$ Error loading post.</p>';
  }
}

document.getElementById('modal-close').addEventListener('click', closeModal);
document.getElementById('post-modal').addEventListener('click', (e) => {
  if (e.target === e.currentTarget) closeModal();
});

function closeModal() {
  document.getElementById('post-modal').style.display = 'none';
  document.body.style.overflow = '';
}

document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

// ---- CONTACT FORM ----
document.getElementById('contact-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('send-btn');
  const status = document.getElementById('form-status');
  btn.disabled = true;
  btn.textContent = '[ TRANSMITTING... ]';
  status.textContent = '';

  const body = {
    name: document.getElementById('c-name').value,
    email: document.getElementById('c-email').value,
    subject: document.getElementById('c-subject').value,
    message: document.getElementById('c-message').value,
  };

  try {
    const res = await fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    if (res.ok) {
      status.textContent = '> ' + data.message;
      status.className = 'form-status success';
      document.getElementById('contact-form').reset();
    } else {
      status.textContent = '! ' + (data.error || 'Transmission failed.');
      status.className = 'form-status error';
    }
  } catch {
    status.textContent = '! Network error. Try again.';
    status.className = 'form-status error';
  } finally {
    btn.disabled = false;
    btn.textContent = '[ TRANSMIT ]';
  }
});

// ---- HELPERS ----
function escHtml(str) {
  if (!str) return '';
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function formatDate(iso) {
  return new Date(iso).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function markdownToHtml(text) {
  if (!text) return '';
  return text
    .replace(/## (.+)/g, '<h2>$1</h2>')
    .replace(/# (.+)/g, '<h1>$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/`(.+?)`/g, '<code style="background:rgba(0,255,157,0.08);padding:1px 5px;border-radius:2px;font-family:var(--font-mono);color:var(--green)">$1</code>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br>')
    .replace(/^(.+)/, '<p>$1</p>');
}

// ---- INIT ----
loadBlog();

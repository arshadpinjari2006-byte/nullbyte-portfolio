# NullByte Portfolio

A full-stack cybersecurity portfolio website built with Node.js, Express.js, and a dark cyberpunk frontend.

---

## Project Structure

```
nullbyte-portfolio/
├── server.js                  # Entry point
├── package.json
├── .env.example
├── .gitignore
│
├── controllers/               # MVC Controllers
│   ├── authController.js      # Login / logout / session
│   ├── blogController.js      # Blog CRUD
│   └── contactController.js   # Contact form storage
│
├── middleware/
│   └── auth.js                # Session auth guard
│
├── routes/
│   ├── auth.js                # /api/auth/*
│   ├── blog.js                # /api/blog/*
│   ├── contact.js             # /api/contact/*
│   └── admin.js               # /admin/*
│
├── data/                      # JSON flat-file database
│   ├── contacts.json          # Stored contact messages
│   └── posts.json             # Blog posts (auto-seeded)
│
└── public/                    # Static frontend
    ├── index.html             # Main portfolio page
    ├── admin.html             # Admin login
    ├── dashboard.html         # Admin dashboard
    ├── css/
    │   └── style.css
    └── js/
        └── main.js
```

---

## Quick Start

### 1. Install Dependencies

```bash
cd nullbyte-portfolio
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env and set a strong SESSION_SECRET
```

### 3. Run the Server

```bash
# Development (auto-restart on changes)
npm run dev

# Production
npm start
```

### 4. Open in Browser

```
http://localhost:3000          → Portfolio
http://localhost:3000/admin    → Admin login
```

---

## Admin Login

| Field    | Value         |
|----------|---------------|
| Username | `admin`       |
| Password | `nullbyte2024`|

> ⚠️ Change the password hash in `controllers/authController.js` before deploying.

### Generating a New Password Hash

```bash
node -e "const b=require('bcryptjs'); b.hash('yourNewPass',10).then(console.log)"
```

Paste the output as `passwordHash` in `authController.js`.

---

## API Endpoints

### Auth
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/auth/login` | Login with credentials |
| POST | `/api/auth/logout` | Destroy session |
| GET  | `/api/auth/status` | Check auth status |

### Blog (Public)
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/blog` | Get all published posts |
| GET | `/api/blog/:slug` | Get single post (increments views) |

### Blog (Admin only)
| Method | Route | Description |
|--------|-------|-------------|
| POST   | `/api/blog` | Create new post |
| PUT    | `/api/blog/:id` | Update post |
| DELETE | `/api/blog/:id` | Delete post |

### Contact (Public)
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/contact` | Submit contact message |

### Contact (Admin only)
| Method | Route | Description |
|--------|-------|-------------|
| GET    | `/api/contact` | Get all messages |
| PATCH  | `/api/contact/:id/read` | Mark as read |
| DELETE | `/api/contact/:id` | Delete message |

---

## Security Features

- **Helmet.js** — Sets secure HTTP headers (CSP, XSS protection, etc.)
- **Rate Limiting** — 100 req/15min globally; 5 contact submissions/hour
- **Session Auth** — HttpOnly cookies, server-side session validation
- **Input Sanitization** — Length limits, email validation, HTML escaping
- **bcryptjs** — Password hashing with salt rounds
- **Secure Routes** — Admin API routes protected by `requireAuth` middleware

---

## Upgrading to MongoDB

Replace the JSON file operations in `controllers/contactController.js` and `controllers/blogController.js` with Mongoose models:

```bash
npm install mongoose
```

```js
// models/Contact.js
const mongoose = require('mongoose');
const ContactSchema = new mongoose.Schema({
  name: String, email: String, subject: String,
  message: String, read: { type: Boolean, default: false }
}, { timestamps: true });
module.exports = mongoose.model('Contact', ContactSchema);
```

Then in server.js:
```js
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/nullbyte');
```

---

## Deploying to Production

1. Set `NODE_ENV=production` and use HTTPS
2. Set `cookie.secure = true` in `server.js`
3. Use a strong `SESSION_SECRET` (32+ random chars)
4. Use a process manager: `npm install -g pm2 && pm2 start server.js`
5. Reverse proxy with Nginx

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Runtime | Node.js |
| Framework | Express.js |
| Auth | express-session + bcryptjs |
| Security | helmet, express-rate-limit |
| Storage | JSON flat-file (MongoDB-ready) |
| Frontend | Vanilla HTML/CSS/JS |
| Fonts | Orbitron, Share Tech Mono, Rajdhani |

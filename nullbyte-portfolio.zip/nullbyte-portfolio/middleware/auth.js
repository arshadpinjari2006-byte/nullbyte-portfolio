const requireAuth = (req, res, next) => {
  if (req.session && req.session.isAuthenticated) {
    return next();
  }
  return res.status(401).json({ error: 'Authentication required.', redirect: '/admin' });
};

const redirectIfAuth = (req, res, next) => {
  if (req.session && req.session.isAuthenticated) {
    return res.redirect('/admin/dashboard');
  }
  return next();
};

module.exports = { requireAuth, redirectIfAuth };

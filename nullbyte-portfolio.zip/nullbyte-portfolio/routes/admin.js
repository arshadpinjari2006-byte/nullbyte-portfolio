const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const path = require('path');

// Serve admin panel (login page is public, dashboard is protected)
router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public', 'admin.html'));
});

router.get('/dashboard', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, '../public', 'dashboard.html'));
});

module.exports = router;

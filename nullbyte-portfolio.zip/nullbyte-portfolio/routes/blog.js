const express = require('express');
const router = express.Router();
const { getAllPosts, getPost, createPost, updatePost, deletePost } = require('../controllers/blogController');
const { requireAuth } = require('../middleware/auth');

// Public
router.get('/', getAllPosts);
router.get('/:slug', getPost);

// Admin-only
router.post('/', requireAuth, createPost);
router.put('/:id', requireAuth, updatePost);
router.delete('/:id', requireAuth, deletePost);

module.exports = router;

const express = require('express');
const router = express.Router();
const { submitContact, getContacts, markRead, deleteContact } = require('../controllers/contactController');
const { requireAuth } = require('../middleware/auth');

router.post('/', submitContact);

// Admin-only
router.get('/', requireAuth, getContacts);
router.patch('/:id/read', requireAuth, markRead);
router.delete('/:id', requireAuth, deleteContact);

module.exports = router;
